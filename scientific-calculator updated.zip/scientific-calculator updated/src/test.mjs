// Import Chai 
import { expect } from 'chai';

// Import scientific calculator functions from the script.js
import {
  cos as calculateCosine,
  sin as calculateSine,
  tan as calculateTangent,
  sqrt as calculateSquareRoot,
  ln as calculateNaturalLog,
  exp as calculateExponential,
  changeSign as toggleSign,
  percent as calculatePercentage,
  square as calculateSquare
} from "./script.js";

describe('Scientific Calculator - Unit Tests', () => {
//cos test
  it('should return 1 when calculating cosine of 0', () => {
    const form = { display: { value: '0' } };
    calculateCosine(form);
    expect(parseFloat(form.display.value)).to.be.approximately(1, 0.0001);
  });
//sine test
  it('should return 1 for sine of π/2', () => {
    const form = { display: { value: (Math.PI / 2).toFixed(5) } };
    calculateSine(form);
    expect(parseFloat(form.display.value)).to.be.approximately(1, 0.0001);
  });
//tan test
  it('should return 0 for tangent of 0', () => {
    const form = { display: { value: '0' } };
    calculateTangent(form);
    expect(parseFloat(form.display.value)).to.be.approximately(0, 0.0001);
  });
//square root test
  it('should return 2 as the square root of 4', () => {
    const form = { display: { value: '4' } };
    calculateSquareRoot(form);
    expect(Number(form.display.value)).to.equal(2);
  });
//ln test
  it('should return 0 as the natural logarithm of 1', () => {
    const form = { display: { value: '1' } };
    calculateNaturalLog(form);
    expect(parseFloat(form.display.value)).to.be.approximately(0, 0.0001);
  });
//exp test
  it('should return 1 as the exponential of 0', () => {
    const form = { display: { value: '0' } };
    calculateExponential(form);
    expect(Number(form.display.value)).to.equal(1);
  });
//changeSign test
  it('should toggle a positive number to negative with toggleSign', () => {
    const input = { value: '8' };
    toggleSign(input);
    expect(input.value).to.equal('-8');
  });
//percent test
  it('should append a % symbol when calculating percentage', () => {
    const input = { value: '25' };
    calculatePercentage(input);
    expect(input.value).to.equal('25%');
  });
//square test
  it('should return 16 as the square of 4', () => {
    const form = { display: { value: '4' } };
    calculateSquare(form);
    expect(Number(form.display.value)).to.equal(16);
  });

});